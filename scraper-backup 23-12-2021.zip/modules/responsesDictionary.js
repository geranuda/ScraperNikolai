module.exports = [
    {
        messages: ["Sure", "yes send me the offer", "now"], //POSITIVE 😊 
        reply: "Ok, I am going to call you and give you an offer."
    },
    {
        messages: ["Who is this?", "I don't  know you", "Who are you"], //negative 😢 
        reply: "Ok never mind"
    },
    {
        messages: ["Hi Gerry,", "Hey Gerry ", "Who are you"], //normal 😎
        reply: "Ok never mind"
    }
];